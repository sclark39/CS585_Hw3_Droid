CSCI585 Homework 3 - team 33

Skyler Clark
Nasr Husami
Anirudh Rekhi

Working
=======


TABLE SCHEMA :
============

id (Primary Key)
X Coordiante
Y coordinate
Microblog String

The keywords are searched in the mocroblog using LIKE keyword
The k value is taken into account by having LIMIT in the query
The distances are ordered using ORDERED keyword.



USER INTERFACE:
==============

There are 3 tabs which allows navigation.

1. Manage DB
------------

Has 3 options

-----------> Open Database : Opens the database if already created otherwise creates a new one
-----------> Populate Tables : Populates it with default microblog entries posted in california and from all over the world
-----------> Drop Databse : Deletes the entries in the table associated with the database



2. Post Blog
------------
One can post Blog Entries here . The current location is shown in the bottom left corner. Submit to insert the microblog 
entry in the database.



3. Browse Blogs
---------------

Allows one to execute keyword search of microblog entries dictated by the entries closest to the current location based on the parameeter k

It has two views. 1. List View
		  2. Map View

When an entry is clicked on the list view, it is shown on the map represented by its coordinates.
When an entry is clicked on the map , or the icon is clicked on the map; the microblog entry is shown.


All the while use the back arrow to go back to the previous screen
  
